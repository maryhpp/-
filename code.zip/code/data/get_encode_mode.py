import cchardet

# 获取文件编码类型
def get_encoding(file):
    # 二进制方式读取，获取字节数据，检测类型
    with open(file, 'rb') as f:
        return cchardet.detect(f.read())['encoding']

file_name = 'vocab_test.txt'
encoding = get_encoding(file_name)
print(encoding)